#include "ast.h"
#include "codegen.h"




#define NB_INST_EMPILER 1
#define NB_INST_DEPILER 1

void semantic(ast* p);