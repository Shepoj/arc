
struct tabsymb{
    char id[32];
    int adresse;
};
typedef struct tabsymb ts[128];